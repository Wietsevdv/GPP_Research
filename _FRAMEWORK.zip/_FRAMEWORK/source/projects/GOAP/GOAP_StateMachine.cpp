#include "stdafx.h"
#include "GOAP_StateMachine.h"

GOAP_StateMachine::GOAP_StateMachine(GOAP_State* startState, Elite::Blackboard* pBlackboard)
    : m_pCurrentState(nullptr),
    m_pBlackboard(pBlackboard)
{
    ChangeState(startState);
}

GOAP_StateMachine::~GOAP_StateMachine()
{
	SAFE_DELETE(m_pBlackboard);
}

void GOAP_StateMachine::Update(float deltaTime)
{
    m_pCurrentState->Update(m_pBlackboard, deltaTime);
}

Elite::Blackboard* GOAP_StateMachine::GetBlackboard() const
{
	return m_pBlackboard;
}

void GOAP_StateMachine::ChangeState(GOAP_State* newState)
{
    if (m_pCurrentState != nullptr)
    {
        m_pCurrentState->OnExit(m_pBlackboard);
    }

    m_pCurrentState = newState;

    if (m_pCurrentState == nullptr)
    {
        std::cout << "currentState switched to a nullptr" << std::endl;
        return;
    }

    m_pCurrentState->OnEnter(m_pBlackboard);
}

void IdleState::OnEnter(Elite::Blackboard* pBlackboard)
{

}

void SeekState::OnEnter(Elite::Blackboard* pBlackboard)
{

}