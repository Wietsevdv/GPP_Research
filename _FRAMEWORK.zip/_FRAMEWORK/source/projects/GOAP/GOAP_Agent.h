#pragma once
#include "projects\Movement\SteeringBehaviors\SteeringAgent.h"
#include "framework\EliteAI\EliteGraphs\EGridGraph.h"

class GOAP_Planner;
class GOAP_Action;
class GOAP_WorldState;

class GOAP_Agent : public SteeringAgent
{
public:
	GOAP_Agent(Elite::Vector2 pos, Elite::Color color);
	virtual ~GOAP_Agent();

	virtual void Update(float dt) override;
	virtual void Render(float dt) override;

	void SetDecisionMaking(Elite::IDecisionMaking* decisionMakingStructure);

	void SetToSeek();
	void SetToIdle();

	void SetTarget(const Elite::Vector2 target) { m_Target = target; }
	const Elite::Vector2& GetTarget() { return m_Target; }

	void SetGoal(const std::string& stateName, bool state);
	void SetGoal(const std::string& agentName, int goToCell);
	void SetCurrentCell(const std::string& agentName, int currentCell);

	void MakePlan(const GOAP_WorldState* goapWorldState, const Elite::GridGraph<Elite::GridTerrainNode, Elite::GraphConnection>* pGridGraph);
	void FollowPlan();

private:
	Elite::IDecisionMaking* m_pDecisionMaking = nullptr;

	ISteeringBehavior* m_pIdle = nullptr;
	ISteeringBehavior* m_pSeek = nullptr;

	Elite::Vector2 m_Target;

	GOAP_Planner* m_pPlanner = nullptr;
	std::vector<GOAP_Action*> m_Actions;
	std::list<GOAP_Action*>* m_pPlan = nullptr;
	std::pair<std::string, bool> m_Goal;
	std::pair<std::string, int> m_MoveToGoal;
	std::pair<std::string, int> m_CurrentCell;
};

