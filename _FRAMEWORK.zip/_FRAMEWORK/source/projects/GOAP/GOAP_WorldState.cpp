#include "stdafx.h"
#include "GOAP_WorldState.h"

void GOAP_WorldState::AddState(const std::string& stateName, bool state, const std::string& stateGroup)
{
	if (m_WorldState.count(stateGroup) == 0) // stateGroup not found
	{
		std::map<std::string, bool> group{std::pair<std::string, bool>(stateName, state)};

		m_WorldState.emplace(stateGroup, group);
	}
	else
	{
		m_WorldState.at(stateGroup).emplace(stateName, state);
	}
}

void GOAP_WorldState::ChangeState(const std::string& stateName, bool newState, const std::string& stateGroup)
{
	if (m_WorldState.count(stateGroup) == 0)
	{
		return;
	}
	else
	{
		if (m_WorldState.at(stateGroup).count(stateName) == 0)
			return;

		m_WorldState.at(stateGroup).at(stateName) = newState;
	}
}

void GOAP_WorldState::AddAgent(const std::string& agentName, GOAP_Agent* pAgent)
{
	m_Agents.emplace(agentName, pAgent);
}

void GOAP_WorldState::SetCellAccessibility(int idx, bool accessibility)
{
	m_CellAccessibility[idx] = accessibility;
}

std::pair<std::string, bool> GOAP_WorldState::GetBridgeState() const
{
	bool bridgeCrossable = m_WorldState.at("AccessibilityInfo").at("BridgeCrossable");
	return std::pair<std::string, bool>("BridgeCrossable", bridgeCrossable);
}
