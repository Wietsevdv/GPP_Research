#pragma once
#ifndef ELITE_GOAP_STATE_MACHINE
#define ELITE_GOAP_STATE_MACHINE

class GOAP_State
{
public:
	GOAP_State() {}
	virtual ~GOAP_State() = default;

	virtual void OnEnter(Elite::Blackboard* pBlackboard) {};
	virtual void OnExit(Elite::Blackboard* pBlackboard) {};
	virtual void Update(Elite::Blackboard* pBlackboard, float deltaTime) {};

};

class IdleState : public GOAP_State
{
public:
	IdleState() : GOAP_State() {};
	virtual void OnEnter(Elite::Blackboard* pBlackboard) override;
};

class SeekState : public GOAP_State
{
public:
	SeekState() : GOAP_State() {};
	virtual void OnEnter(Elite::Blackboard* pBlackboard) override;
};

//
//MACHINE
//
class GOAP_StateMachine final : public Elite::IDecisionMaking
{
public:
	GOAP_StateMachine(GOAP_State* startState, Elite::Blackboard* pBlackboard);
	virtual ~GOAP_StateMachine();

	virtual void Update(float deltaTime) override;
	Elite::Blackboard* GetBlackboard() const;

	void ChangeState(GOAP_State* newState);
		
private:
	std::vector<GOAP_State*> m_pStates;
	GOAP_State* m_pCurrentState;
	Elite::Blackboard* m_pBlackboard = nullptr; // takes ownership of the blackboard
};
#endif