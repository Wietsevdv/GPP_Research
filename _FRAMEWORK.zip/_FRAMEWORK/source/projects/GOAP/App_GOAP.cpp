#include "stdafx.h"
#include "App_GOAP.h"
#include "GOAP_Agent.h"
#include "GOAP_WorldState.h"
#include "GOAP_StateMachine.h"

#include "framework\EliteAI\EliteGraphs\EliteGraphAlgorithms\EAstar.h"
#include "framework\EliteAI\EliteGraphs\EliteGraphAlgorithms\EBFS.h"

using namespace Elite;

App_GOAP::~App_GOAP()
{
	SAFE_DELETE(m_pGOAPAgent);
	SAFE_DELETE(m_pWorldState);
	SAFE_DELETE(m_pGridGraph);
	SAFE_DELETE(m_pGraphRenderer);
	SAFE_DELETE(m_pGraphEditor);

	for (auto& s : m_pStates)
	{
		SAFE_DELETE(s);
	}
}

void App_GOAP::Start()
{
	m_pGraphEditor = new GraphEditor();
	m_pGraphRenderer = new GraphRenderer();
	
	DEBUGRENDERER2D->GetActiveCamera()->SetZoom(39.0f);
	DEBUGRENDERER2D->GetActiveCamera()->SetCenter(Elite::Vector2(73.0f, 35.0f));

	MakeGridGraph();

	//GOAP
	m_pGOAPAgent = new GOAP_Agent(Elite::Vector2(10, 10), Elite::Color(1.f, 0.f, 0.f));

	m_pWorldState = new GOAP_WorldState();
	m_pWorldState->AddState("BridgeCrossable", false, "AccessibilityInfo");
	m_pWorldState->AddAgent("007", m_pGOAPAgent);

	SetCellInfo();

	//FSM
	GOAP_State* pIdleState = new IdleState();
	GOAP_State* pSeekState = new SeekState();
	m_pStates.push_back(pIdleState);
	m_pStates.push_back(pSeekState);

	Blackboard* pBlackboard = new Blackboard();
	pBlackboard->AddData("Agent", m_pGOAPAgent);
	pBlackboard->AddData("GridGraph", m_pGridGraph);

	GOAP_StateMachine* pSM = new GOAP_StateMachine(pIdleState, pBlackboard);

	m_pGOAPAgent->SetDecisionMaking(pSM);
}

void App_GOAP::Update(float deltaTime)
{
	if (INPUTMANAGER->IsMouseButtonUp(InputMouseButton::eLeft))
	{
		auto const mouseData = INPUTMANAGER->GetMouseData(InputType::eMouseButton, InputMouseButton::eLeft);
		Vector2 mousePos = DEBUGRENDERER2D->GetActiveCamera()->ConvertScreenToWorld({ static_cast<float>(mouseData.X), static_cast<float>(mouseData.Y) });

		int nodeIdx = m_pGridGraph->GetNodeIdxAtWorldPos(mousePos);

		int currentCell = m_pGridGraph->GetNodeIdxAtWorldPos({ m_pGOAPAgent->GetPosition().x, m_pGOAPAgent->GetPosition().y });

		m_pGOAPAgent->SetGoal("007", nodeIdx);
		m_pGOAPAgent->SetCurrentCell("007", currentCell);
		m_pGOAPAgent->MakePlan(m_pWorldState, m_pGridGraph);
		m_pGOAPAgent->FollowPlan();
	}

	m_pGOAPAgent->Update(deltaTime);
	UpdateImGui();
}

void App_GOAP::Render(float deltaTime) const
{
	UNREFERENCED_PARAMETER(deltaTime);
	
	m_pGraphRenderer->RenderGraph(m_pGridGraph, true, false, false, false);

	m_pGOAPAgent->Render(deltaTime);
}

void App_GOAP::MakeGridGraph()
{
	m_pGridGraph = new GridGraph<GridTerrainNode, GraphConnection>(COLUMNS, ROWS, m_SizeCell, false, false, 1.f, 1.5f);

	for (int i{}; i < ROWS; ++i)
	{
		for (int j{}; j < COLUMNS; ++j)
		{
			m_pGridGraph->GetNode(j + i * COLUMNS)->SetPosition(Vector2( m_SizeCell * 0.5f + m_SizeCell * j, m_SizeCell * 0.5f + m_SizeCell * i));
		}
	}

	m_pGridGraph->GetNode(188)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(168)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(148)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(128)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(108)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(88)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(68)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(48)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(28)->SetTerrainType(TerrainType::Water);
	m_pGridGraph->GetNode(8)->SetTerrainType(TerrainType::Water);

	m_pGridGraph->RemoveConnectionsToAdjacentNodes(188);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(168);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(148);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(128);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(108);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(88);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(68);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(48);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(28);
	m_pGridGraph->RemoveConnectionsToAdjacentNodes(8);
}

void App_GOAP::UpdateImGui()
{
#ifdef PLATFORM_WINDOWS
#pragma region UI
	//UI
	{
		//Setup
		int menuWidth = 200;
		int const width = DEBUGRENDERER2D->GetActiveCamera()->GetWidth();
		int const height = DEBUGRENDERER2D->GetActiveCamera()->GetHeight();
		bool windowActive = true;
		ImGui::SetNextWindowPos(ImVec2((float)width - menuWidth - 10, 10));
		ImGui::SetNextWindowSize(ImVec2((float)menuWidth, (float)height - 20));
		ImGui::Begin("GOAP", &windowActive, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse);
		ImGui::PushAllowKeyboardFocus(false);

		//Elements
		ImGui::Text("CONTROLS");
		ImGui::Indent();
		ImGui::Text("LMB: target");
		ImGui::Unindent();

		/*Spacing*/ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing(); ImGui::Spacing();

		ImGui::Text("STATS");
		ImGui::Indent();
		ImGui::Text("%.3f ms/frame", 1000.0f / ImGui::GetIO().Framerate);
		ImGui::Text("%.1f FPS", ImGui::GetIO().Framerate);
		ImGui::Unindent();

		/*Spacing*/ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing(); ImGui::Spacing();

		//End
		ImGui::PopAllowKeyboardFocus();
		ImGui::End();
	}
#pragma endregion
#endif
}

void App_GOAP::CalculatePath()
{
	//Check if valid start and end node exist
	if (startPathIdx != invalid_node_index
		&& endPathIdx != invalid_node_index
		&& startPathIdx != endPathIdx)
	{
		auto pathFinderAStar = AStar<GridTerrainNode, GraphConnection>(m_pGridGraph, m_pHeuristicFunction);
		auto startNode = m_pGridGraph->GetNode(startPathIdx);
		auto endNode = m_pGridGraph->GetNode(endPathIdx);

		m_vPath = pathFinderAStar.FindPath(startNode, endNode);

		std::cout << "New Path Calculated" << std::endl;
	}
	else
	{
		std::cout << "No valid start and end node..." << std::endl;
		m_vPath.clear();
	}
}

void App_GOAP::SetCellInfo()
{
	//this sets all cells to the right of the water to true (means: needs crossable bridge to reach)
	for (int i{}; i < ROWS; ++i)
	{
		for (int j{ 9 }; j < 20; ++j)
		{
			m_pWorldState->SetCellAccessibility(j + i * COLUMNS, true);
		}
	}
}
