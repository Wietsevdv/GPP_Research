#include "stdafx.h"
#include "GOAP_Planner.h"
#include "GOAP_WorldState.h"


GOAP_Planner::~GOAP_Planner()
{
	for (auto& pAction : m_Plan)
	{
		SAFE_DELETE(pAction);
	}
}

std::list<GOAP_Action*>* GOAP_Planner::MakePlan(std::pair<std::string, int> moveToCell, std::pair<std::string, int> currentCell, const std::vector<GOAP_Action*>& actions, const GOAP_WorldState* pGoapWorldState, const Elite::GridGraph<Elite::GridTerrainNode, Elite::GraphConnection>* pGridGraph)
{
	for (const GOAP_Action* action : actions)
	{
		if (dynamic_cast<const Goto_Action*>(action))
		{
			const Goto_Action* pGoToAction{ dynamic_cast<const Goto_Action*>(action) };

			if (pGoToAction->GetEffect(moveToCell.first, moveToCell.second) == moveToCell)
			{
				std::pair<std::string, bool> neededChange{ pGoToAction->CheckProceduralPrecondition(moveToCell.second, pGoapWorldState) };

				if (neededChange.first == "")
				{
					m_Plan.push_back(new Goto_Action(pGridGraph->GetNode(moveToCell.second)->GetPosition()));
					return &m_Plan;
				}
				else
				{
					MakePlan(neededChange, pGoapWorldState->GetBridgeState(), actions, pGoapWorldState);

					m_Plan.push_back(new Goto_Action(pGridGraph->GetNode(moveToCell.second)->GetPosition()));
					return &m_Plan;
				}
			}
		}
	}


	return nullptr;
}

void GOAP_Planner::MakePlan(std::pair<std::string, bool> stateToChange, std::pair<std::string, bool> currentState, const std::vector<GOAP_Action*>& actions, const GOAP_WorldState* pGoapWorldState)
{
	for (const GOAP_Action* action : actions)
	{
		if (dynamic_cast<const CloseBridge*>(action))
		{
			const CloseBridge* pCloseBridgeAction{ dynamic_cast<const CloseBridge*>(action) };

			if (pCloseBridgeAction->GetEffect() == stateToChange)
			{
				m_Plan.push_back(new CloseBridge());
			}
		}
	}
}
