#pragma once

class GOAP_Agent;

class GOAP_WorldState
{
public:
	GOAP_WorldState() = default;
	~GOAP_WorldState() = default;

	GOAP_WorldState(const GOAP_WorldState& other) = delete;
	GOAP_WorldState(GOAP_WorldState&& other) = delete;
	GOAP_WorldState operator=(const GOAP_WorldState& other) = delete;
	GOAP_WorldState operator=(GOAP_WorldState&& other) = delete;

	void AddState(const std::string& stateName, bool state, const std::string& stateGroup);
	void ChangeState(const std::string& stateName, bool newState, const std::string& stateGroup);
	const std::map<std::string, std::map<std::string, bool>>& GetWorldState() { return m_WorldState; }

	void AddAgent(const std::string& agentName, GOAP_Agent* pAgent);

	void SetCellAccessibility(int idx, bool accessibility);
	bool GetCellAccessibility(int cellIdx) const { return m_CellAccessibility[cellIdx]; }

	std::pair<std::string, bool> GetBridgeState() const;

private:
	std::map<std::string, std::map<std::string, bool>> m_WorldState;

	std::map<std::string, GOAP_Agent*> m_Agents;

	bool m_CellAccessibility[200] = {}; //magic nr for small implementation
								   //this array will represent each cells accessibility with a boolean saying whether or not the bridge must be crossable or not
								   //0 == does not require bridge to reach
								   //1 == requires bridge to reach
};

