#include "stdafx.h"
#include "GOAP_Actions.h"
#include "GOAP_WorldState.h"
#include "GOAP_Agent.h"

//GOTO
Goto_Action::Goto_Action()
	: m_GotoPos{ 0, 0 }
{
}

Goto_Action::Goto_Action(const Elite::Vector2& gotoPos)
	: m_GotoPos{ gotoPos }
{
}

std::pair<std::string, bool> Goto_Action::CheckProceduralPrecondition(int cellIdx, const GOAP_WorldState* pGoapWorldState) const
{
	if (pGoapWorldState->GetCellAccessibility(cellIdx))
	{
		return std::pair<std::string, bool>("BridgeCrossable", true);
	}
	return std::pair<std::string, bool>();
}

std::pair<std::string, int> Goto_Action::GetEffect(const std::string& agentName, int gotoCell) const
{
	return std::pair<std::string, int>(agentName, gotoCell);
}

void Goto_Action::Start(GOAP_Agent* pAgent)
{
	pAgent->SetTarget(m_GotoPos);
	pAgent->SetToSeek();
}

bool Goto_Action::Update(GOAP_Agent* pAgent, float dt)
{
	return true;
}


//CLOSEBRIDGE
CloseBridge::CloseBridge()
{
	m_Effects.emplace("BridgeCrossable", true);
}

std::pair<std::string, bool> CloseBridge::GetEffect() const
{
	return std::pair<std::string, bool>("BridgeCrossable", true);
}

void CloseBridge::Start(GOAP_Agent* pAgent)
{
	pAgent->SetTarget({50, 50});
	pAgent->SetToSeek();
}

bool CloseBridge::Update(GOAP_Agent* pAgent, float dt)
{
	DEBUGRENDERER2D->DrawSolidCircle({ 50.f, 50.f }, 10.f, { 1.f, 1.f }, Elite::Color(0.f, 1.f, 0.f));
	if (pAgent->GetPosition().DistanceSquared({ 50, 50 }) < 3)
	{
		return true;
	}
	return false;
}
