#pragma once
#include "GOAP_Actions.h"
#include "framework\EliteAI\EliteGraphs\EGridGraph.h"

class GOAP_WorldState;

class GOAP_Planner final
{
public:
	GOAP_Planner() = default;
	~GOAP_Planner();

	GOAP_Planner(const GOAP_Planner& other) = delete;
	GOAP_Planner(GOAP_Planner&& other) = delete;
	GOAP_Planner operator=(const GOAP_Planner& other) = delete;
	GOAP_Planner operator=(GOAP_Planner&& other) = delete;

	std::list<GOAP_Action*>* MakePlan(std::pair<std::string, int> moveToCell, std::pair<std::string, int> currentCell, const std::vector<GOAP_Action*>& actions, const GOAP_WorldState* pGoapWorldState, const Elite::GridGraph<Elite::GridTerrainNode, Elite::GraphConnection>* pGridGraph);
	void MakePlan(std::pair<std::string, bool> stateToChange, std::pair<std::string, bool> currentState, const std::vector<GOAP_Action*>& actions, const GOAP_WorldState* pGoapWorldState);
private:
	std::list<GOAP_Action*> m_Plan;
};

