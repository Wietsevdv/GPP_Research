#include "stdafx.h"
#include "GOAP_Agent.h"
#include "GOAP_Planner.h"
#include "GOAP_Actions.h"
#include "projects/Movement/SteeringBehaviors/Steering/SteeringBehaviors.h"

GOAP_Agent::GOAP_Agent(Elite::Vector2 pos, Elite::Color color)
	: SteeringAgent(4.0f)
{
	m_BodyColor = color;
	SetPosition(pos);
	SetMass(0.f);
	SetAutoOrient(true);

	m_pIdle = new Idle();
	m_pSeek = new Seek();

	m_Target = { 0.f, 0.f };

	m_pPlanner = new GOAP_Planner();

	m_Actions.push_back(new Goto_Action());
	m_Actions.push_back(new CloseBridge());
}

GOAP_Agent::~GOAP_Agent()
{
	SAFE_DELETE(m_pDecisionMaking);
	SAFE_DELETE(m_pIdle);
	SAFE_DELETE(m_pSeek);
	SAFE_DELETE(m_pPlanner);
	
	for (auto& pAction : m_Actions)
	{
		SAFE_DELETE(pAction);
	}
}

void GOAP_Agent::Update(float dt)
{
	if (m_pDecisionMaking)
		m_pDecisionMaking->Update(dt);

	if (m_pPlan && m_pPlan->size() > 0)
	{
		if (m_pPlan->front()->Update(this, dt))
		{
			SAFE_DELETE(m_pPlan->front());
			m_pPlan->pop_front();

			if (m_pPlan->size() > 0)
				m_pPlan->front()->Start(this);
		}
	}
	SteeringAgent::Update(dt);
}

void GOAP_Agent::Render(float dt)
{
	SteeringAgent::Render(dt);
}

void GOAP_Agent::SetDecisionMaking(Elite::IDecisionMaking* decisionMakingStructure)
{
	m_pDecisionMaking = decisionMakingStructure;
}

void GOAP_Agent::SetToSeek()
{
	m_pSeek->SetTarget(m_Target);
	SetSteeringBehavior(m_pSeek);
}

void GOAP_Agent::SetToIdle()
{
	SetSteeringBehavior(m_pIdle);
}

void GOAP_Agent::SetGoal(const std::string& stateName, bool state)
{
	m_Goal.first = stateName;
	m_Goal.second = state;
}

void GOAP_Agent::SetGoal(const std::string& agentName, int goToCell)
{
	m_MoveToGoal.first = agentName;
	m_MoveToGoal.second = goToCell;
}

void GOAP_Agent::SetCurrentCell(const std::string& agentName, int currentCell)
{
	m_CurrentCell.first = agentName;
	m_CurrentCell.second = currentCell;
}

void GOAP_Agent::MakePlan(const GOAP_WorldState* pGoapWorldState, const Elite::GridGraph<Elite::GridTerrainNode, Elite::GraphConnection>* pGridGraph)
{
	m_pPlan = m_pPlanner->MakePlan(m_MoveToGoal, m_CurrentCell, m_Actions, pGoapWorldState, pGridGraph);
}

void GOAP_Agent::FollowPlan()
{
	if (m_pPlan && m_pPlan->size() > 0)
		m_pPlan->front()->Start(this);
}
