#pragma once

class GOAP_WorldState;
class GOAP_Agent;

class GOAP_Action
{
public:
	GOAP_Action() = default;
	virtual ~GOAP_Action() = default;

	GOAP_Action(const GOAP_Action& other) = delete;
	GOAP_Action(GOAP_Action&& other) = delete;
	GOAP_Action operator=(const GOAP_Action& other) = delete;
	GOAP_Action operator=(GOAP_Action&& other) = delete;

	virtual void Start(GOAP_Agent* pAgent) = 0;
	virtual bool Update(GOAP_Agent* pAgent, float dt) = 0;

protected:
	std::map<std::string, bool> m_PreConditions;
	std::map<std::string, bool> m_Effects;
};

class Goto_Action : public GOAP_Action
{
public:
	Goto_Action();
	Goto_Action(const Elite::Vector2& gotoPos);

	virtual std::pair<std::string, bool> CheckProceduralPrecondition(int cellIdx, const GOAP_WorldState* pGoapWorldState) const;

	std::pair<std::string, int> GetEffect(const std::string& agentName, int gotoCell) const;

	virtual void Start(GOAP_Agent* pAgent) override;
	virtual bool Update(GOAP_Agent* pAgent, float dt) override;

private:
	Elite::Vector2 m_GotoPos;
};

class CloseBridge : public GOAP_Action
{
public:
	CloseBridge();

	std::pair<std::string, bool> GetEffect() const;

	virtual void Start(GOAP_Agent* pAgent) override;
	virtual bool Update(GOAP_Agent* pAgent, float dt) override;
};