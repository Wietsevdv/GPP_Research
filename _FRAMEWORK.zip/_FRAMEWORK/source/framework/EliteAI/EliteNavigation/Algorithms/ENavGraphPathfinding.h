#pragma once
#include <vector>
#include <iostream>
#include "framework/EliteMath/EMath.h"
#include "framework\EliteAI\EliteGraphs\ENavGraph.h"
#include "framework\EliteAI\EliteGraphs\EliteGraphAlgorithms\EAStar.h"

namespace Elite
{
	class NavMeshPathfinding
	{
	public:
		static std::vector<Vector2> FindPath(Vector2 startPos, Vector2 endPos, NavGraph* pNavGraph, std::vector<Vector2>& debugNodePositions, std::vector<Portal>& debugPortals)
		{
			//Create the path to return
			std::vector<Vector2> finalPath{};

			//Get the start and endTriangle
			const Triangle* pStartTriangle{ pNavGraph->GetNavMeshPolygon()->GetTriangleFromPosition(startPos) };
			const Triangle* pEndTriangle{ pNavGraph->GetNavMeshPolygon()->GetTriangleFromPosition(endPos) };

			if (pStartTriangle == nullptr || pEndTriangle == nullptr)
				return finalPath;

			if (pStartTriangle == pEndTriangle)
			{
				//NavGraphNode* pEndNode = new NavGraphNode(pNavGraph->GetAllNodes().size(), endPos);
				//pNavGraph->AddNode(pEndNode);
				finalPath.push_back(endPos);

				return finalPath;
			}

			//We have valid start/end triangles and they are not the same
			//=> Start looking for a path
			//Copy the graph
			auto pNavGraphClone{ pNavGraph->Clone() };
			
			//Create extra node for the Start Node (Agent's position
			NavGraphNode* pStartNode = new NavGraphNode(pNavGraphClone->GetAllNodes().size(), startPos);
			pNavGraphClone->AddNode(pStartNode);
			
			ConnectStartEndNode(pStartNode, pStartTriangle, pNavGraph, pNavGraphClone.get());
			
			//Create extra node for the endNode
			NavGraphNode* pEndNode = new NavGraphNode(pNavGraphClone->GetAllNodes().size(), endPos);
			pNavGraphClone->AddNode(pEndNode);

			ConnectStartEndNode(pEndNode, pEndTriangle, pNavGraph, pNavGraphClone.get());
			
			//Run A star on new graph
			AStar<NavGraphNode, GraphConnection2D> aStar(pNavGraphClone.get(), HeuristicFunctions::Euclidean);
			std::vector<NavGraphNode*> aStarPath{ aStar.FindPath(pStartNode, pEndNode) };
			
			//OPTIONAL BUT ADVICED: Debug Visualisation
			debugNodePositions.clear();
			for (auto& a : aStarPath)
			{
				debugNodePositions.push_back(a->GetPosition());
			}

			//Run optimiser on new graph, MAKE SURE the A star path is working properly before starting this section and uncommenting this!!!
			m_Portals = SSFA::FindPortals(aStarPath, pNavGraph->GetNavMeshPolygon());
			debugPortals = m_Portals;

			finalPath = SSFA::OptimizePortals(m_Portals);
			
			return finalPath;
		}

		static void ConnectStartEndNode(NavGraphNode* pNode, const Triangle* pTriangle, NavGraph* pNavGraph, IGraph<NavGraphNode, GraphConnection2D>* pNavGraphCopy)
		{
			std::vector<NavGraphNode*> foundNodes{};

			for (int i{}; i < 3; ++i)
			{
				int idx = pNavGraph->GetNodeIdxFromLineIdx(pNavGraph->GetNavMeshPolygon()->GetLines()[pTriangle->metaData.IndexLines[i]]->index);
				if (idx != invalid_node_index)
				{
					foundNodes.push_back(pNavGraph->GetNode(idx));
				}
			}

			switch (foundNodes.size())
			{
			case 1:
			{
				pNavGraphCopy->AddConnection(new GraphConnection2D(pNode->GetIndex(), foundNodes[0]->GetIndex()));
				break;
			}
			case 2:
			{
				pNavGraphCopy->AddConnection(new GraphConnection2D(pNode->GetIndex(), foundNodes[0]->GetIndex()));
				pNavGraphCopy->AddConnection(new GraphConnection2D(pNode->GetIndex(), foundNodes[1]->GetIndex()));
				break;
			}
			case 3:
			{
				pNavGraphCopy->AddConnection(new GraphConnection2D(pNode->GetIndex(), foundNodes[0]->GetIndex()));
				pNavGraphCopy->AddConnection(new GraphConnection2D(pNode->GetIndex(), foundNodes[1]->GetIndex()));
				pNavGraphCopy->AddConnection(new GraphConnection2D(pNode->GetIndex(), foundNodes[2]->GetIndex()));
			}
			}
		}

	protected:
		static std::vector<Portal> m_Portals;
	};
}

std::vector<Portal> NavMeshPathfinding::m_Portals = {};