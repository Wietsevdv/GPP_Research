//=== General Includes ===
#include "stdafx.h"
#include "EFiniteStateMachine.h"
using namespace Elite;

FiniteStateMachine::FiniteStateMachine(FSMState* startState, Blackboard* pBlackboard)
    : m_pCurrentState(nullptr),
    m_pBlackboard(pBlackboard)
{
    ChangeState(startState);
}

FiniteStateMachine::~FiniteStateMachine()
{
    SAFE_DELETE(m_pBlackboard);
}

void FiniteStateMachine::AddTransition(FSMState* startState, FSMState* toState, FSMCondition* condition)
{
    auto it = m_Transitions.find(startState);
    if (it == m_Transitions.end())
    {
        m_Transitions[startState] = Transitions();
    }
   
    m_Transitions[startState].push_back(std::make_pair(condition, toState));
}

void FiniteStateMachine::Update(float deltaTime)
{
    auto transitionIt = m_Transitions.find(m_pCurrentState);

    if (transitionIt != m_Transitions.end())
    {
        for (auto& transition : transitionIt->second) //for all transitions of m_pCurrentState
        {
            FSMCondition* cond = transition.first;
            FSMState* state = transition.second;

            if (cond->Evaluate(m_pBlackboard))
            {
                ChangeState(state);
                break;
            }
        }
    }
    else
        return;
    
    m_pCurrentState->Update(m_pBlackboard, deltaTime);
    
}

Blackboard* FiniteStateMachine::GetBlackboard() const
{
    return m_pBlackboard;
}

void FiniteStateMachine::ChangeState(FSMState* newState)
{
    if (m_pCurrentState != nullptr)
    {
        m_pCurrentState->OnExit(m_pBlackboard);

    }

    m_pCurrentState = newState;

    if (m_pCurrentState == nullptr)
    {
        std::cout << "currentState switched to a nullptr" << std::endl;
        return;
    }

    m_pCurrentState->OnEnter(m_pBlackboard);
}
